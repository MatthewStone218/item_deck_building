/////////////////////////
//HOW TO USE THIS ASSET//
/////////////////////////

Hello, fellow game developer! Thank you for downloading the Slime Gobbler asset pack. Here are a few pointers to help you navigate and make sense of this zip file.

Tips:

- There are 3 slime color variants! These each have the own folder.

- Inside the color folders, you'll find that each animation has its own folder.

- Alternatively, spritesheets can be found in the spritesheet folders, along with two metadata files. (Pick the format you like.)

- The recommended frame duration is 75 ms/frame (equivalent to 15 frames/sec).

Got questions? Hit me up at:
@untiedgames (twitter)
contact@untiedgames.com (email)

Thanks again! Check out more of my asset packs at http://untiedgames.com/assets.
-Will
