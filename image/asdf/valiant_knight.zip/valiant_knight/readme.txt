//////////
//THANKS//
//////////

Hi there, this is Will from unTied Games! Nice to meet you.

Super huge THANK YOU for downloading this asset... It means a lot to me that you've chosen it for your game!
If you use this asset in your game, give me a shoutout if you can at @untiedgames, so I can follow along on your development journey!
Want to follow me? Sign up for my newsletter! Or follow me using the Twitter / FB / Youtube links below.
Newsletter signup: http://untiedgames.com/signup

Did you know? You can get access to ALL of my assets if you support me on Patreon!
Check it out: http://patreon.com/untiedgames
You read that right! At the $10 tier, you can get access to ALL of my assets. Not your cup of tea? At the $5 tier, you can get access to all my assets that are 1 year old or more. There's also a lot more than just pixel art... I make Youtube videos, indie games, development logs, and more!

MORE LINKS:
Browse my other assets: untiedgames.itch.io/
Watch me make pixel art, games, and more: youtube.com/c/unTiedGamesTV
Follow on Facebook: facebook.com/untiedgames
Follow on Twitter: twitter.com/untiedgames
Visit my blog: untiedgames.com

Thanks again,
- Will

///////////////////
//VERSION HISTORY//
///////////////////

Version 2.0 (12/13/18)
	- Added two additional attack animations!
	- Added get hit animation.
	- Added die animation.
	- Adjusted run animation to be less jarring when transitioning from idle to run.
	- Updated color palette.
	- Added three additional color themes.
	- Repackaged block effect spritesheet.
	- Various other minor fixes.

Version 1.0 (3/19/17)
	- Initial release.

/////////////////////////
//HOW TO USE THIS ASSET//
/////////////////////////

Hello! Thank you for downloading the Valiant Knight asset pack. Here are a few pointers to help you navigate and make sense of this zip file.

- In the root folder, you will find folders corresponding to each color style for the knight.

- In any of the style folders, you will find a folder named PNG. This folder contains the animation frames as individual PNGs. Each animation has its own folder.

- In the style folders, you will also find a folder named spritesheet. This folder contains the spritesheet for that style as well as a metadata file for parsing the spritesheet.

- The recommended frame duration is 0.75 seconds per frame (15 FPS).

- The attack animations each have two frames at the end that are intended to be a transition back to the idle animation. If you want to chain the attacks together into a combo, skip those frames.

Any questions?
Email me at contact@untiedgames.com and I'll try to answer as best I can!

-Will